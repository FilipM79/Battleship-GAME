import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.Arrays;

class Main {
    public static void main(String[] args) throws Exception {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        // start coding here
        String[] input = reader.readLine().trim().split("\\s+");
        reader.close();

        System.out.println("[]".equals(Arrays.toString(input)) ? 0 : input.length);

    }
}


