class ArrayOperations {
    public static void printCorners(int[][] twoDimArray) {
        // write your code here

        int rows = twoDimArray.length;
        int columns = twoDimArray[0].length;

        int leftTop = twoDimArray[0][0];
        int rightTop = twoDimArray[0][columns - 1];
        int leftBottom = twoDimArray[rows - 1][0];
        int rightBottom = twoDimArray[rows - 1][columns - 1];

        System.out.println(leftTop + " " + rightTop);
        System.out.println(leftBottom + " " + rightBottom);
    }
}