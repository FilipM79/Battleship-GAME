
import java.util.Scanner;

class Main {
    public static void main(String[] args) {
        // put your code here
        Scanner scanner =  new Scanner(System.in);

        int n = scanner.nextInt();
        int m = scanner.nextInt();

        int[][] array = new int[n][m];
        int maximum = 0;
        String maxIndex = null;

        for (int i = 0; i < n; i++) {
            for (int j = 0; j < m; j++) {
                array[i][j] = scanner.nextInt();

                if (i == 0 && j == 0) {
                    maximum = array[i][j];
                    maxIndex = i + " " + j;

                } else if (array[i][j] > maximum) {
                    maximum = array[i][j];
                    maxIndex = i + " " + j;
                }
            }
        }
        System.out.println(maxIndex);
    }
}