
class Box {

    double height;
    double width;
    double length;

    public double getVolume() {
        return height * width * length;
    }
}
