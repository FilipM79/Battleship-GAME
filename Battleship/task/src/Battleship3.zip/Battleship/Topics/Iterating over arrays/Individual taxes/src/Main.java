import java.util.*;

public class Main {
    public static void main(String[] args) {
        // write your code here
        Scanner scanner = new Scanner(System.in);

        //System.out.println("Num of companies: ");
        //System.out.print("> ");
        int n = scanner.nextInt();
        double[] incomes = new double[n];
        int[] taxesPercentage = new int[n];

        //System.out.println("Input " + n + " income values: ");
        for (int i = 0; i < incomes.length; i++) {
            incomes[i] = scanner.nextInt();
        }

        //System.out.println("Input " + n + " values tor taxes percentage: ");
        for (int i = 0; i < taxesPercentage.length; i++) {
            taxesPercentage[i] = scanner.nextInt();
        }

        double[] maxTax = new double[n];
        final int oneHundred = 100;
        for (int i = 0; i < maxTax.length; i++) {
            maxTax[i] = incomes[i] / oneHundred * taxesPercentage[i];
        }

        int companyMaxTaxIndex = 0;
        final int one = 1;
        for (int i = 0; i < maxTax.length; i++) {
            companyMaxTaxIndex = maxTax[i] > maxTax[companyMaxTaxIndex] ? i : companyMaxTaxIndex;
        }

        //System.out.println(Arrays.toString(maxTax));
        System.out.println(companyMaxTaxIndex + one);

        scanner.close();
    }
}