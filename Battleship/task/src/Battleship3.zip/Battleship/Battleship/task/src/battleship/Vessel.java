package battleship;
class Vessel {
    Vessel(String name, int length) {
        this.name = name;
        this.length = length;
    }
    String name;
    int length;
}
