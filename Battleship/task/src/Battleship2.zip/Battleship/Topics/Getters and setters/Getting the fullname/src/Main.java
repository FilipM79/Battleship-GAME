

class User {
    private String firstName;
    private String lastName;

    public User() {
        this.firstName = "";
        this.lastName = "";
    }

    public void setFirstName(String firstName) {
        // write your code here
        if (null != firstName && !"".equals(firstName)) {
            this.firstName = firstName;
        }
    }

    public void setLastName(String lastName) {
        // write your code here
        if (null != lastName && !"".equals(lastName)) {
            this.lastName = lastName;
        }
    }

    public String getFullName() {

        // write your code here
        String blank = "";
        if (blank.equals(firstName) && blank.equals(lastName)) {
            return "Unknown";
        } else if (blank.equals(firstName)) {
            return lastName;
        } else if (blank.equals(lastName)) {
            return firstName;
        } else {
            return firstName + " " + lastName;
        }
    }
}