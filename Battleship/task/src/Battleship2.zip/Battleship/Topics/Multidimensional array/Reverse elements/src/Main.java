
class ArrayOperations {
    public static void reverseElements(int[][] twoDimArray) {
        // write your code here

        int rows = twoDimArray.length;
        int columns = twoDimArray[0].length;
        int columnsLengthToIndex = columns - 1;

        int[][] tempArray = new int[rows][columns];

        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < columns; j++) {
                tempArray[i][columnsLengthToIndex - j] = twoDimArray[i][j];
            }
        }

        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < columns; j++) {
                twoDimArray[i][j] = tempArray[i][j];
            }
        }
    }
}