import java.util.Scanner;

class Main {
    public static void main(String[] args) {
        // put your code here
        Scanner scanner = new Scanner(System.in);
        int numRows = scanner.nextInt();  // n
        int numSeats = scanner.nextInt(); // m
        scanner.nextLine();

        int[][] cinemaArr = new int[numRows][numSeats];


        for (int i = 0; i < numRows; i++) {
            for (int j = 0; j < numSeats; j++) {
                cinemaArr[i][j] = scanner.nextInt();
            }
        }

        int seatWanted = scanner.nextInt(); // k
        int rowCount = 0;

        for (int i = 0; i < numRows; i++) {
            if (rowCount != 0) {
                break;
            }

            int freeSeat = 0;

            for (int j = 0; j < numSeats; j++) {
                int currentSeat = cinemaArr[i][j];

                if (currentSeat == 0) {
                    freeSeat++;
                } else {
                    freeSeat = 0;
                }

                if (freeSeat == seatWanted) {
                    rowCount = i + 1;
                    break;
                }
            }
        }

        System.out.println(rowCount);
    }
}
