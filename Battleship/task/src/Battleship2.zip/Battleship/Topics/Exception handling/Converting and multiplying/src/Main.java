import java.util.Scanner;

class Main {
    public static void main(String[] args) {
        // put your code here

        Scanner scanner = new Scanner(System.in);

        String inputString;
        int inputStringtoIntTimes10;
        final int ten = 10;
        int condition = 1;
        final String zero = "0";

        while (condition != 0) {

            inputString = scanner.nextLine();

            if (!inputString.equals(zero)) {
                try {
                    inputStringtoIntTimes10 = Integer.parseInt(inputString) * ten;
                    System.out.println(inputStringtoIntTimes10);
                } catch (NumberFormatException ex) {
                    System.out.println("Invalid user input: " + inputString);
                }
            } else {
                condition = 0;
            }
        }
    }
}