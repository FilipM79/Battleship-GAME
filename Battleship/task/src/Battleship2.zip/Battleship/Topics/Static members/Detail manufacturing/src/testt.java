public class testt {

    public static String requestProduct() {

        return String.valueOf(ManufacturingController.counter);
    }

    public static int getNumberOfProducts() {
        // write your code here
        return ManufacturingController.counter++;
    }
}
