
class Car {

    int yearModel;
    String make;
    int speed;
    final int speedStepChange = 5;

    public void accelerate() {

        speed += speedStepChange;
    }
    
    public void brake() {
        if (speed >= speedStepChange) {
            speed -= speedStepChange;
        } else {
            speed = 0;
        }
    }
}
