
class Patient {

    String name;

    public void say() {
        System.out.println("Hello, my name is " + name + ", I need a doctor.");
    }
}