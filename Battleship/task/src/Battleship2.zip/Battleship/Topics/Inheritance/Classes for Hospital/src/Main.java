
class Person {

}

class Employee extends Person {

}

class Doctor extends Employee {

}

class Patient extends Person {

}