package org.demo;

import org.demo.mypackage.b;

public class A {

    org.demo.mypackage.b b = new b();


}
