import java.util.InputMismatchException;
import java.util.Scanner;

class Driver {
    String name;
    Boolean isDoorLocked;
    Boolean isBeltFastened;

    public Driver(String name, Boolean isDoorLocked, Boolean isBeltFastened) {
        this.name = name;
        this.isDoorLocked = isDoorLocked;
        this.isBeltFastened = isBeltFastened;

    }

    public void closeDoor() {
        this.isDoorLocked = true;
    }

    public void fastenBelt() {
        this.isBeltFastened = true;
    }

    public void drive(boolean isBeltFastened, boolean isDoorLocked) throws DriverNotReadyException {
        //put your code
        if (isBeltFastened && isDoorLocked) {
            System.out.println("Here we go");
        } else if (!isBeltFastened || !isDoorLocked) {
            throw new DriverNotReadyException("Close the door or fasten your seatbelt");
        }
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String name = scanner.next();
        try {
            Boolean isDoorLocked = scanner.nextBoolean();
            Boolean isBeltFastened = scanner.nextBoolean();
            Driver driver = new Driver(name, isDoorLocked, isBeltFastened);
            driver.drive(isBeltFastened, isDoorLocked);

        } catch (DriverNotReadyException e) {
            System.out.println(e.getMessage());
        } catch (InputMismatchException ime) {
            System.out.println("Use a valid input: first input a name, " +
                    "and then 'true' or 'false' for the next two inputs.");
        }
    }
}

class DriverNotReadyException extends Exception {
    public DriverNotReadyException(String message) {
        super(message);
    }
}