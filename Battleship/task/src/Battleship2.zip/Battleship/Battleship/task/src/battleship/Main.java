package battleship;

public class Main {

    public static void main(String[] args) {
        // Write your code here
        Game game = new Game();
            game.play();
    }
}