
class Counter {

    int current;

    public void inc() {
        current += 1;
    }
    
    public int getCurrent() {
        return current;
    }
}
