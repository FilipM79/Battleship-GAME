
class Clock {

    int hours = 12;
    int minutes = 0;
    final int fiftyNine = 59;
    final int twelve = 12;
    final int one = 1;

    void next() {
        // implement me
        if (minutes < fiftyNine && hours <= twelve) {
            minutes++;
        } else if (minutes >= fiftyNine && hours < twelve) {
            minutes = 0;
            hours++;
        } else if (minutes >= fiftyNine && hours == twelve) {
            minutes = 0;
            hours = one;
        }
    }
}