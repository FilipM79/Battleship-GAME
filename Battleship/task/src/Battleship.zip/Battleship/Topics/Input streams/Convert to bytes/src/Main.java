import java.io.InputStream;

class Main {
    public static void main(String[] args) throws Exception {
        InputStream inputStream = System.in;

        byte[] arr = inputStream.readAllBytes();
        for (byte i = 0; i < arr.length; i++) {
            System.out.print(arr[i]);
 
        }
        inputStream.close();
    }
}
