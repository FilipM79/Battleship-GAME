package org.demo.mypackage;

public class C {
}
